<?php
    include 'connection.php';

    session_start();
    $applicant_id=$_SESSION['applicant_id'];
    

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/userinfo.css">
    <link rel="stylesheet" type="text/css" href="../userprofilecss/header-footer.css">
    <link rel="stylesheet" type="text/css" href="../userprofilecss/font.css">
    <link rel="stylesheet" type="text/css" href="./css/after-login.css">
</head>

<body>

    <!-- Header -->

    <div class="header">
        <div class="left">
            <a class="logo-home" href="../../homepage/applicant-after-login.php"><h1 class="site-name">Hire Gateway</h1></a>
        </div>
        <div class="middle">
            <nav class="nav">
                <ul>
                    <li><a href="../../homepage/applicant-after-login.php">home</a></li>
                    <li><a href="#">find jobs</a></li>
                    <li><a href="talentPool/index.html">talent pool</a></li>
                    <li><a href="#">feedback</a></li>
                    <li><a href="#">about us</a></li>
                </ul>
            </nav>
        </div>
        <div class="right">
            
                <a href="../userprofile/applicant/dashbaord.php"><img class="profile-icon" src="images/profile.jpg"></a>
        </div>
    </div>


    <div class="containe">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        
                        <span class="title"><h1>User Dashboard</h1></span>
                    </a>
                </li>

                <li>
                    <a href="dashbaord.php">
                        <span class="icon">
                            <ion-icon name="home-outline" active></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>


                <li>
                    <a id="manage" href="editprofile.php">
                        <span class="icon">
                            <ion-icon name="create-outline"></ion-icon>
                        </span>
                        <span class="title">Edit profile</span>
                    </a>
                </li>


                <li>
                    <a href="appliedjob.php">
                        <span class="icon">
                            <ion-icon name="reader-outline"></ion-icon>
                        </span>
                        <span class="title">Applied Jobs</span>
                    </a>
                </li>

                <li>
                    <a id="payment" href="payment.html?">
                        <span class="icon">
                            <ion-icon name="star-half-outline"></ion-icon>
                        </span>
                        <span class="title">Talent pool</span>
                    </a>
                </li>


                
                <li>
                    <a
                        href="../../homepage/applogout.php">
                        <span class="icon">
                            <ion-icon name="alert-circle-outline"></ion-icon>
                        </span>
                        <span class="title">Log out</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>


    <div class="main">
        <div class="topbar">
            <div class="toggle">
                <ion-icon name="menu"></ion-icon>
            </div>

        </div>

        <div class="header-table">
            

            <table class="job-info" border="1">
              <caption>
                  Applied Job Information
              </caption>
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Nic</th>
                <th>Email</th>
                <th>Applied Job</th>
                <th>Offered Company</th>
                <th>Deadline</th>
                <th colspan="2">Action</th>

              </tr>
  
  
  
  
              <?php
  
                  
  
                  $query="SELECT 
                  a.application_id,
                  a.firstname,
                  a.lastname,
                  a.nic,
                  app.email,
                  j.jobtitle,
                  j.deadline,
                  j.company
                  FROM 
                  application AS a
                  JOIN 
                  applicant AS app ON a.applicant_id = app.applicant_id
                  JOIN 
                  job AS j ON a.job_id = j.jobid
                  WHERE 
                  app.applicant_id = $applicant_id;";

  
                  $data=mysqli_query($con,$query);
                  $result=mysqli_num_rows($data);
  
                  while($row=mysqli_fetch_array($data)){
                      ?>
                      
                      <tr>
                        <td><?php echo $row["firstname"]?></td>
                        <td><?php echo $row["lastname"]?></td>
                        <td><?php echo $row["nic"]?></td>
                        <td><?php echo $row["email"]?></td>
                        <td><?php echo $row["jobtitle"]?></td>
                        <td><?php echo $row["company"]?></td>
                        <td><?php echo $row["deadline"]?></td>

                       
                        <td><button class="update-btn"><a href="../../applicant/update.php?application_id=<?php echo $row["application_id"];?>">Update</a></td>
                        <td><button class="delete-btn"><a href="../../applicant/delete.php?application_id=<?php echo $row["application_id"];?>">Delete</a></td>
  
                      </tr>
                  
                  <?php
                  }
                  ?>
  
  
  
  
                  
              
            
  
          
        </div>
  
        
    </div>

   




    <script src="./js/myAds.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!--import from google to add icons-->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>

</html>