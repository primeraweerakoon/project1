//add hovered class to selected list item
// add hovered class to selected list item
let list = document.querySelectorAll(".navigation li");

function activeLink() {
  list.forEach((item) => {
    item.classList.remove("hovered");
  });
  this.classList.add("hovered");
}

list.forEach((item) => item.addEventListener("mouseover", activeLink));

// Menu Toggle
let toggle = document.querySelector(".toggle");
let navigation = document.querySelector(".navigation");
let main = document.querySelector(".main");

toggle.onclick = function () {
  navigation.classList.toggle("active");
  main.classList.toggle("active");
};

//creating dinamically update when user uplode user image
var userImageElement = document.getElementById("user-image");

//creating a file reader object
var reader = new FileReader();

//creating function to read that object
reader.onload = function (event) {
  userImageElement.src = event.target.result;
};

reader.readAsDataURL(imageFile);