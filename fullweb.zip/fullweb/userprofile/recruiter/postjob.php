<?php
    include 'connection.php';

    
    session_start();

    $rid=$_SESSION['rid'];

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/userinfo.css">
    <link rel="stylesheet" type="text/css" href="../userprofilecss/header-footer.css">
    <link rel="stylesheet" type="text/css" href="../userprofilecss/font.css">
    <link rel="stylesheet" type="text/css" href="./css/after-login.css">
</head>

<body>

    <!-- Header -->

    <div class="header">
        <div class="left">
            <a class="logo-home" href="../homepage.html"><h1 class="site-name">Hire Gateway</h1></a>
        </div>
        <div class="middle">
            <nav class="nav">
                <ul>
                    <li><a href="../../homepage/recruiter-after-login.php">home</a></li>
                    <li><a href="../talentPool/index.php">talent pool</a></li>
                    <li><a href="#">Post job</a></li>
                    <li><a href="#">Job status</a></li>
                    <li><a href="#">feedback</a></li>
                    <li><a href="#">about us</a></li>
                </ul>
            </nav>
        </div>
        <div class="right">
                
                <a href="../userprofile/applicant/dashbaord.php"><img class="profile-icon" src="images/profile.jpg"></a><br>
        </div>
    </div>


    <div class="containe">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        
                        <span class="title"><h1>User Dashboard</h1></span>
                    </a>
                </li>

                <li>
                    <a href="dashbaord.php">
                        <span class="icon">
                            <ion-icon name="home-outline" active></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>


                <li>
                    <a id="manage" href="editprofile.php">
                        <span class="icon">
                            <ion-icon name="create-outline"></ion-icon>
                        </span>
                        <span class="title">Edit profile</span>
                    </a>
                </li>


                <li>
                    <a href="postjob.php">
                        <span class="icon">
                            <ion-icon name="reader-outline"></ion-icon>
                        </span>
                        <span class="title">Post Jobs</span>
                    </a>
                </li>

                <li>
                    <a id="payment" href="payment.html?">
                        <span class="icon">
                            <ion-icon name="star-half-outline"></ion-icon>
                        </span>
                        <span class="title">Talent pool</span>
                    </a>
                </li>


                
                <li>
                    <a
                        href="file:///C:/Users/pramu/OneDrive%20-%20Sri%20Lanka%20Institute%20of%20Information%20Technology/IWT-project/src/logout.html">
                        <span class="icon">
                            <ion-icon name="alert-circle-outline"></ion-icon>
                        </span>
                        <span class="title">Log out</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>


    <div class="main">
        <div class="topbar">
            <div class="toggle">
                <ion-icon name="menu"></ion-icon>
            </div>

        </div>

        <div class="header-table">
            

            <table class="job-info" border="1">
              <caption>
                  Post Job Information
              </caption>
              <tr>
                <th>Job Tile</th>
                <th>Company</th>
                <th>Deadline</th>
                <th>Description</th>
                <th>Experience</th>
                <th>Salary</th>
                <th>Education Qulification</th>
                <th colspan="2">Action</th>

              </tr>
  
  
  
  
              <?php
  
                  //session_start();
                  $email=$_SESSION['email'];
  
                  $query="SELECT * FROM Job WHERE recruiter_id ='$rid' ;";

  
                  $data=mysqli_query($con,$query);
                  $result=mysqli_num_rows($data);
  
                  while($row=mysqli_fetch_array($data)){
                      ?>
                      
                      <tr>
                        <td><?php echo $row["jobtitle"]?></td>
                        <td><?php echo $row["company"]?></td>
                        <td><?php echo $row["deadline"]?></td>
                        <td><?php echo $row["description"]?></td>
                        <td><?php echo $row["experience"]?></td>
                        <td><?php echo $row["salary"]?></td>
                        <td><?php echo $row["edu_qul"]?></td>

                        <<td><button class="update-btn"><a href="../../recruiter/update.php?jobid=<?php echo $row["jobid"];?>">Update</a></td>
                        <td><button class="delete-btn"><a  href="../../recruiter/delete.php?jobid=<?php echo $row["jobid"];?>">Delete</a></td>
  
                      </tr>
                  
                  <?php
                  }
                  ?>
  
  
  
  
                  
              
            
  
          
        </div>
  
        
    </div>

   




    <script src="./js/myAds.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!--import from google to add icons-->
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>

</html>