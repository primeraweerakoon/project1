<!DOCTYPE html>
<html>
    <head>
        <title>LOGIN PAGE</title>
        <link rel="stylesheet" href="css/login.css">
    </head>

    <body>
        <div class="center">
            <h1>Login Applicant</h1>
            <form class="form"  action="app-login-php.php"  method="POST">

              <div class="inputbox">
                <input type="text" id="email" name="email" required="required">
                <span>Email</span>
              </div>
              <div class="inputbox">
                <input type="password" id="password" name="password" required="required">
                <span>Password</span>
              </div>
              <div class="inputbox">
                <input type="submit" id="save_btn" name="save_btn" value="login">
              </div>
            </form>
          </div>
    </body>
</html>