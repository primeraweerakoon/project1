<?php
    session_start(); 

   
    if (isset($_SESSION['email'])) {
       
        $rid = $_SESSION['rid']; 

       
        session_destroy();
        
        
        header("Location: homepage.php?rid=$rid");
        exit();
    } else {
       
        header("Location:homepage.php");
        exit();
    }
?>