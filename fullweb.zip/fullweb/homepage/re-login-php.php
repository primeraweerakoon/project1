<?php

    include("connection.php");



    if(isset($_POST['save_btn']))
    {

        $email = $_POST['email'];
        $password = $_POST['password'];

        $query="SELECT * FROM recruiter where email='$email' and password='$password'";
        $result=mysqli_query($con,$query);
        $count=mysqli_num_rows($result);

        while($record=mysqli_fetch_assoc($result)){

            if($record["email"]==$email &&  $record["password"]==$password)
            {

                session_start();

                $select="SELECT  rid FROM recruiter WHERE email='$email'";
                $data=mysqli_query($con,$select);
                $row=mysqli_fetch_array($data);

                $_SESSION['rid'] = $row['rid'];

                $_SESSION['email'] = $email;

                


                header("Location:recruiter-after-login.php");
                //echo"Login Ok";
            }
            else{
                echo"Login Failed please cheak your UserName and Password";
            }
        }

    }
       



        

    
?>