<?php
    session_start(); 

   
    if (isset($_SESSION['email'])) {
       
        $applicant_id = $_SESSION['applicant_id']; 

       
        session_destroy();
        
        
        header("Location: homepage.php?applicant_id=$applicant_id");
        exit();
    } else {
       
        header("Location:homepage.php");
        exit();
    }
?>