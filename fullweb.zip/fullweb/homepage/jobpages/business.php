<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>
            Business & Finance
        </title>
        
        <link rel="stylesheet" type="text/css" href="pages.css/styles.css">
        <link rel="stylesheet" type="text/css" href="pages.css/header-footer.css">
        <link rel="stylesheet" type="text/css" href="pages.css/font.css">
        <link rel="stylesheet" type="text/css" href="pages.css/cards.css">
        <link rel="stylesheet" type="text/css" href="pages.css/pages.css">

    </head>
    <body>
        
        <!-- Header -->

        <div class="header">
            <div class="left">
                <a class="logo-home" href="../homepage.php"><h1 class="site-name">Hire Gateway</h1></a>
            </div>
            <div class="middle">
                <nav class="nav">
                    <ul class="main-nav-list">
                        <li class="main-nav"><a class="home" href="../homepage.php">home</a></li>
                        <li class="main-nav"><a class="talent-pool" href="../../talentPool/index.php">talent pool</a></li>
                        <li class="main-nav"><a class="feedback" href="#">feedback</a></li>
                        <li class="main-nav"><a class="about-us" href="#">about us</a></li>
                    </ul>
                </nav>
            </div>
            <div class="right">
                <button class="sign-in"><a href="#">Sign in</a></button>
                <button class="sign-up"><a href="#">Sign up</a></button>
            </div>
        </div>


        <div class="container">
            <p class="top-ads">Business & Finance</p>
            <div class="box-container">
                <div class="box">
                    <img src="../images/HTML5_badge.svg" alt="HTML 5">
                    <h3>HTML 5</h3>
                    <p>About this</p>
                    <a href="#" class="btn">Apply Now</a>
                </div>
                <div class="box">
                    <img src="../images/CSS3_Logo.svg" alt="CSS 3">
                    <h3>CSS 3</h3>
                    <p>About this</p>
                    <a href="#" class="btn">Apply Now</a>
                </div>
                <div class="box">
                    <img src="../images/javascript.svg" alt="Javascript">
                    <h3>Javascript</h3>
                    <p>About this</p>
                    <a href="#" class="btn">Apply Now</a>
                </div>
                <div class="box">
                    <img src="../images/javascript.svg" alt="Javascript">
                    <h3>Javascript</h3>
                    <p>About this</p>
                    <a href="#" class="btn">Apply Now</a>
                </div>
                <div class="box">
                    <img src="../images/javascript.svg" alt="Javascript">
                    <h3>Javascript</h3>
                    <p>About this</p>
                    <a href="#" class="btn">Apply Now</a>
                </div>
                <div class="box">
                    <img src="../images/javascript.svg" alt="Javascript">
                    <h3>Javascript</h3>
                    <p>About this</p>
                    <a href="#" class="btn">Apply Now</a>
                </div>
                <div class="box">
                    <img src="../images/javascript.svg" alt="Javascript">
                    <h3>Javascript</h3>
                    <p>About this</p>
                    <a href="#" class="btn">Apply Now</a>
                </div>
                <div class="box">
                    <img src="../images/javascript.svg" alt="Javascript">
                    <h3>Javascript</h3>
                    <p>About this</p>
                    <a href="#" class="btn">Apply Now</a>
                </div>
                <div class="box">
                    <img src="../images/javascript.svg" alt="Javascript">
                    <h3>Javascript</h3>
                    <p>About this</p>
                    <a href="#" class="btn">Apply Now</a>
                </div>
            </div>
        </div>
    </body>
</html>