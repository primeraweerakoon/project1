<!doctype html>
<html>
    <head>
        <title>Applicant Form</title>
        <link rel="stylesheet" href="css/application.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    </head>

    <body>
        <section class="container">
            <header>Job Information</header>

            
                
            </div>
            
            <form class="form"  action="application-php.php"  method="POST"  onsubmit="return validateForm()">
                
                <div class="column">
                    <div class="input-box">
                        <label for="company">Company</label>
                        <input type="text" id="company" name="company" placeholder="Enter Company Name " >
                        <span id="companyError" class="error"></span>
                    </div>

                    <div class="input-box">
                        <label for="jobtitle">Job Title</label>
                        <input type="text" id="jobtitle" name="jobtitle" placeholder="Enter Job Ttile">
                        <span id="jobtitleError" class="error"></span>
                    </div>
                    
                </div>


                

                <div class="column">
                    <div class="input-box">
                        <label for="salary">salary</label>
                        <input type="text" id="salary" name="salary" placeholder="Enter Salary">
                        <span id="salaryError" class="error"></span>
                    </div>

                    <div class="input-box">
                        <label for="deadline">Deadline</label>
                        <input type="text" id="deadline" name="deadline" placeholder="Deadline">
                        <span id="deadlineError" class="error"></span>
                    </div>

                    <div class="input-box">
                        <label for=" experience">Experience</label>
                        <input type="text" id=" experience" name=" experience" placeholder="Deadline">
                        <span id="experienceError" class="error"></span>
                    </div>

                </div>






             

                <div class="column"> 

                    <div class="input-box">

                        <label for="description">Description</label><br>
                        <textarea id="description" name="description"> </textarea>
                        <span id="descriptionError" class="error"></span>

                    </div>

                </div>

                    <div class="input-box">

                        <label for="education_qual">Education Qualification</label><br>
                        <textarea id="education_qual" name="education_qual"> </textarea>
                        <span id="education_qualError" class="error"></span>

                    </div>

                    <div class="input-box">

                        <label for="skill">Skill</label><br>
                        <textarea id="skill" name="skill"> </textarea>
                        <span id="skillError" class="error"></span>

                    </div>
                

                

                    
                


                
                

                




                

                <a href="#">
                    <button type="submit" name="save_btn" id="save_btn">Post Job</button>
                  
                </a>

                
                   
                    
                
                
                 
            </form>

        </section>

        <script>
            // Function to validate if the input is a number
            function isValidNumber(value) {
                return /^\d+$/.test(value);
            }

            // Function to validate if the input is not empty
            function validateNotEmpty(value, errorElement, fieldName) {
                if (value.trim() === '') {
                    errorElement.innerHTML = `<i class="fas fa-exclamation-circle error-icon"></i>${fieldName} is required`;
                    return false;
                } else {
                    errorElement.textContent = '';
                    return true;
                }
            }

            // Function to validate salary
            function validateSalary() {
                const salary = document.getElementById('salary');
                const salaryError = document.getElementById('salaryError');
                const salaryValue = salary.value.trim();
                if (salaryValue === '') {
                    salaryError.innerHTML = '<i class="fas fa-exclamation-circle error-icon"></i>Salary is required';
                    return false;
                } else if (!isValidNumber(salaryValue)) {
                    salaryError.innerHTML = '<i class="fas fa-exclamation-circle error-icon"></i>Salary must be a valid number';
                    return false;
                } else {
                    salaryError.textContent = '';
                    return true;
                }
            }

            // Real-time validation for input fields
            function setupRealTimeValidation(inputId, errorId, fieldName, validationFunction) {
                const input = document.getElementById(inputId);
                const error = document.getElementById(errorId);

                input.addEventListener('blur', function () {
                    validateNotEmpty(input.value, error, fieldName);
                    if (validationFunction) {
                        validationFunction();
                    }
                });

                input.addEventListener('input', function () {
                    validateNotEmpty(input.value, error, fieldName);
                    if (validationFunction) {
                        validationFunction();
                    }
                });
            }

            // Setup real-time validation for all fields
            setupRealTimeValidation('company', 'companyError', 'Company Name');
            setupRealTimeValidation('jobtitle', 'jobtitleError', 'Job Title');
            setupRealTimeValidation('salary', 'salaryError', 'Salary', validateSalary);
            setupRealTimeValidation('deadline', 'deadlineError', 'Deadline');
            setupRealTimeValidation('experience', 'experienceError', 'Experience');
            setupRealTimeValidation('description', 'descriptionError', 'Description');
            setupRealTimeValidation('education_qual', 'education_qualError', 'Education Qualification');
            setupRealTimeValidation('skill', 'skillError', 'Skill');

            // Function to validate all fields on form submission
            function validateForm() {
                const isValidCompany = validateNotEmpty(document.getElementById('company').value, document.getElementById('companyError'), 'Company Name');
                const isValidJobTitle = validateNotEmpty(document.getElementById('jobtitle').value, document.getElementById('jobtitleError'), 'Job Title');
                const isValidSalary = validateSalary();
                const isValidDeadline = validateNotEmpty(document.getElementById('deadline').value, document.getElementById('deadlineError'), 'Deadline');
                const isValidExperience = validateNotEmpty(document.getElementById('experience').value, document.getElementById('experienceError'), 'Experience');
                const isValidDescription = validateNotEmpty(document.getElementById('description').value, document.getElementById('descriptionError'), 'Description');
                const isValidEducationQual = validateNotEmpty(document.getElementById('education_qual').value, document.getElementById('education_qualError'), 'Education Qualification');
                const isValidSkill = validateNotEmpty(document.getElementById('skill').value, document.getElementById('skillError'), 'Skill');

                // Return true if all validations pass
                return isValidCompany && isValidJobTitle && isValidSalary && isValidDeadline && isValidExperience && isValidDescription && isValidEducationQual && isValidSkill;
            }
        </script>
            

    </body>
</html>