<?php

    session_start();
    include 'connection.php';

    



    $jobid=$_GET['jobid'];
    


     $select="SELECT  * FROM job WHERE jobid='$jobid'";
     $data=mysqli_query($con,$select);
     $row=mysqli_fetch_array($data);

     $_SESSION['jobid'] = $jobid;


?>







<!doctype html>
<html>
    <head>
        <title>Applicant Form</title>
        <link rel="stylesheet" href="css/application.css">
        <link rel="stylesheet" href="css/header-footer.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    </head>

    <body>
    


        <section class="container">
            <header>Job Information</header>

            
                
            </div>
            
            <form class="form"  action="update-php.php"  method="POST">
                
                <div class="column">
                    <div class="input-box">
                        <label for="company">Company</label>
                        <input type="text" id="company" name="company" value="<?php echo $row["company"]?>" >
                    </div>

                    <div class="input-box">
                        <label for="jobtitle">Job Title</label>
                        <input type="text" id="jobtitle" name="jobtitle" value="<?php echo $row["jobtitle"]?>">
                    </div>
                    
                </div>


                

                <div class="column">
                    <div class="input-box">
                        <label for="salary">salary</label>
                        <input type="text" id="salary" name="salary"value="<?php echo $row["salary"]?>">
                    </div>

                    <div class="input-box">
                        <label for="deadline">Deadline</label>
                        <input type="text" id="deadline" name="deadline" value="<?php echo $row["deadline"]?>">
                    </div>

                    <div class="input-box">
                        <label for=" experience">Experience</label>
                        <input type="text" id=" experience" name=" experience" value="<?php echo $row["experience"]?>">
                    </div>

                </div>


                <div class="column"> 

                    <div class="input-box">

                        <label for="description">Description</label><br>
                        <textarea id="description" name="description"> <?php echo $row["description"]?> </textarea>

                    </div>

                </div>

                    <div class="input-box">

                        <label for="education_qual">Education Qualification</label><br>
                        <textarea id="education_qual" name="education_qual"> <?php echo $row["edu_qul"]?> </textarea>

                    </div>

                    <div class="input-box">

                        <label for="skill">Skill</label><br>
                        <textarea id="skill" name="skill"> <?php echo $row["skill"]?> </textarea>

                    </div>
                

                

                    
                


                
                

                




                

                <a href="#">
                    <button type="submit" name="update_btn" id="update_btn">Update Details</button>
                  
                </a>

                
                   
                    
                
                
                 
            </form>

        </section>

        

    </body>
</html>